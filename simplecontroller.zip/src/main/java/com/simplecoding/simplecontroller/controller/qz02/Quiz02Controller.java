package com.simplecoding.simplecontroller.controller.qz02;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Quiz02Controller {
    @GetMapping("/qu02/quiz01")
    public String quiz01(Model model, @RequestParam(defaultValue = "")String dname){
    model.addAttribute("dmane",dname);
    return "qz02/quiz01";
    }
//    퀴즈2
    @GetMapping("/qu02/quiz02")
    public String quiz02(Model model,@RequestParam(defaultValue = "0")int dno){
        model.addAttribute("dno",dno);
        return "qz02/quiz02";
    }
}
