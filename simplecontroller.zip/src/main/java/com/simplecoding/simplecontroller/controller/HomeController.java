package com.simplecoding.simplecontroller.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
// @~~: 어노테이션, 어떤 기능이 있는것(함수와 비슷)
@Controller    // 클래스에 컨트롤러 기능을 추가하는것
public class HomeController {
//    스프링의 기본 인터넷주소 : http://localhost:8080
//    기본 인터넷주소 +  @GetMapping 주소 :  http://localhost:8080 + / -> http://localhost:8080/
//     사용자 접속 첫화면 : 홈(스터디 했던 메인 화면을 넣으면 나옴)
    @GetMapping("/")            //@GetMapping("추가인터넷주소")
    public String home(){
        return "home";            // jsp 파일명 : 대소문자 구분, .jsp 생략
    }
}
