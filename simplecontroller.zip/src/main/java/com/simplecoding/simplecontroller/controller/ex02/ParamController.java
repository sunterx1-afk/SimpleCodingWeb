package com.simplecoding.simplecontroller.controller.ex02;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ParamController {
//        쿼리스트링 샘플 : http://기본주소/?변수=값
//        a페이지 : ?변수=값 => b페이지 : 변수를 받아서 화면에 표시할수 있습니다.
//  사용법: 1) http://localhost:8080/ex02/example01?name=홍길동 (웹브라우저 주소창)
//         2) ?name=홍길동 : 웹매개변수 name 에 홍길동 저장함
//         3) @RequestParam : 쿼리스트링의 변수를 가져오는 어노테이션
//         4) 사용법: @RequestParam(옵션) String 매개변수
//             의미:  ?name 의 값을 String name 에 저장합니다.
//         5) 옵션 :(defaultValue = "") : ?name=, 값없이 보내면 "" 빈글자로 저장하세요라는 의미
    @GetMapping("/ex02/example01")// 추가인터넷주소(기본주소x,퀴리스트링(?)x)
    public String example01(Model model,@RequestParam(defaultValue = "")String name){
        model.addAttribute("name",name);
        return "ex02/example01";
    }
}
