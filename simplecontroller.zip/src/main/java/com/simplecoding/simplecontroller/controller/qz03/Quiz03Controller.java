package com.simplecoding.simplecontroller.controller.qz03;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@Controller
public class Quiz03Controller {
    @GetMapping("/qz03/quiz01")
    public String quiz01(Model model,
                         @RequestParam(defaultValue = "")String dno,
                         @RequestParam(defaultValue = "")String dname,
                         @RequestParam(defaultValue = "")String loc){
        model.addAttribute("dno",dno);
        model.addAttribute("dname",dname);
        model.addAttribute("loc",loc);
        return "qz03/quiz01";
    }
    @GetMapping("/qz03/quiz02")
    public String quiz02(Model model,
            @RequestParam(defaultValue = "")String eno,
                         @RequestParam(defaultValue = "")String ename,
                         @RequestParam(defaultValue = "")String job,
                         @RequestParam(defaultValue = "")String hiredate) {
        List<String > list= new ArrayList<>();
        list.add(eno);
        list.add(ename);
        list.add(job);
        list.add(hiredate);
        model.addAttribute("list",list);
        return "qz03/quiz02";
    }
}
