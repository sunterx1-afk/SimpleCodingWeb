package com.simplecoding.simplecontroller.controller.ex03;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

@Controller
public class MultiParamController {
//    예제1
    @GetMapping("/ex03/example01")
    public String example01(Model model,
      @RequestParam(defaultValue = "")String name,@RequestParam(defaultValue = "")String id){
        model.addAttribute("name",name);
        model.addAttribute("id",id);
        return "ex03/example01";
    }
//    예제3
    @GetMapping("/ex03/example02")
    public String example02(Model model,
                            @RequestParam(defaultValue = "")String fno,
                            @RequestParam(defaultValue = "")String title,
                            @RequestParam(defaultValue = "")String content) {
        List<String > list = new ArrayList<>();//향상된 배열
//        사용법 : 배열변수.add(값);// 추가
        list.add(fno);
        list.add(title);
        list.add(content);
        model.addAttribute("list",list);
                return "ex03/example02";
    }
}