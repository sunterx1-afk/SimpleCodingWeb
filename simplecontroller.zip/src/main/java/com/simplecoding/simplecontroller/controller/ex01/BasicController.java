package com.simplecoding.simplecontroller.controller.ex01;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

// 컨트롤로 역할 : url과 jsp(화면)를 연결시켜주는 곳
// 예제1
@Controller
public class BasicController {
    @GetMapping("/ex01/example01")
    public  String example01(){
        return "ex01/example01";   // ex01 폴더 안에 example01.jsp를 의미함
    }
// 예제3
    @GetMapping("/example02")
    public String example02(Model model){
        model.addAttribute("greeting","안녕 스프링");
        //jsp로 변수에 감아 값을 전송할 수 있음("geeting":키(변수),"안녕"값:)
        //        사용법: model.addAttribute("키(변수)", "값");
        return "ex01/example02";
    }
// 예제5
    @GetMapping("/ex01/example03")
    public String example03(Model model){
        model.addAttribute("greeting","안녕스프링");
        model.addAttribute("greeting2","안녕스프링2");
        return "ex01/example03";
    }
// 예제7
    @GetMapping("/ex01/example04")
    public String example04(Model model){
        model.addAttribute("str","abc");
        model.addAttribute("num",10);
        model.addAttribute("value",true);
        return "ex01/example04";
    }

}
