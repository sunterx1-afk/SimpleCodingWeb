package com.simplecoding.simplecontroller.controller.qz01;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Quiz01Controller {
//    quiz01
    @GetMapping("/qz01/quiz01")
    public String quiz01(){
        return "qz01/quiz01";
    }

//    quiz02
    @GetMapping("/qz01/quiz02")
    public String quiz02(Model model){
        model.addAttribute("quiz","안녕 페이지");
        return "qz01/quiz02";
    }
//    quiz03
    @GetMapping("/qz01/quiz03")
    public String quiz03 (Model model){
        model.addAttribute("quiz","안녕 페이지");
        model.addAttribute("quiz2","안녕 페이지2");
        model.addAttribute("quiz3","안녕 페이지3");
        return "qz01/quiz03";
    }
//    quiz04
    @GetMapping("/qz01/quiz04")
    public String quiz04(Model model){
        model.addAttribute("str","hello");
        model.addAttribute("num",10);
        model.addAttribute("value",10.5);
        return "qz01/quiz04";
    }

}
