package com.simplecoding.simplecontroller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimplecontrollerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimplecontrollerApplication.class, args);
	}

}
