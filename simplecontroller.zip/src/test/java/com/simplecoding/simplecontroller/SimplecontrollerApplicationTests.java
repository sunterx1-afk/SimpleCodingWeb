package com.simplecoding.simplecontroller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimplecontrollerApplicationTests {

	@Test
	void contextLoads() {
	}

}
